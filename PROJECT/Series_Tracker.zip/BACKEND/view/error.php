<!DOCTYPE html>
<html>
    <head>
        <title>Where did I leave off!!</title>
        <link rel="stylesheet" type="text/css" href="main.css"/>
    </head>
    <body>
        <header>
            <h1>Where did I leave off!!</h1>
        </header>
        <main>
            <h1 class="top">Error</h1>
            <p><?php echo $error; ?></p>
        </main>
    </body>
</html>
