<h1>Navigation Menu</h1>
    <p><a href="index.php?action=show_main_menu">Main Menu</a></p>
    <p><a href="index.php?action=show_new_user">New User</a></p>
    <p><a href="index.php?action=show_new_series">New Series</a></p>
    <p><a href="index.php?action=show_new_episodes">New Episodes</a></p>
    <p><a href="index.php?action=logout">Logout</a></p>